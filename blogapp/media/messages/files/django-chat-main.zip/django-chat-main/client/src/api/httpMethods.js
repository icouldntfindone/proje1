const HttpMethods = {
  POST: "POST",
};

export default HttpMethods;
