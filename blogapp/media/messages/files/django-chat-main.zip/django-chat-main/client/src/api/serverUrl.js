const ServerUrl = {
  BASE_URL: "http://127.0.0.1:8000/",
  WS_BASE_URL: "ws://127.0.0.1:8000/",
};

export default ServerUrl;
